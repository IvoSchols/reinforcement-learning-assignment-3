# reinforcement-learning-assignment-3
We used ray to paralelize the the individual runs of the experiments.
Python version used is 3.9

Here are commands to run the experiments:


```bash
python part1.py
```
Runs the first set of experiments with leraning rate and gamma.


```bash
python part2.py
```
Runs the second set of experiments with different environment sizes. 
